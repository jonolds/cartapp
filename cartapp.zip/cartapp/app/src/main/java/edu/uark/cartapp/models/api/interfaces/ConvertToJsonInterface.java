package edu.uark.cartapp.models.api.interfaces;

import org.json.JSONObject;

/* ==== APP ConvertToJsonInterface.java ====*/
public interface ConvertToJsonInterface {
	JSONObject convertToJson();
}