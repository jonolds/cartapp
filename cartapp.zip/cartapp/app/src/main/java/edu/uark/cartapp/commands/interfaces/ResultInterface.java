package edu.uark.cartapp.commands.interfaces;

/* ==== APP ResultInterface.java ====*/
public interface ResultInterface<T> {
	T execute();
}