package edu.uark.cartapp.models.api.interfaces;

/* ==== APP FieldNameInterface.java ====*/
public interface FieldNameInterface {
	String getFieldName();
}