package edu.uark.cartapp.models.api.interfaces;

/* ==== APP PathElementInterface.java ====*/
public interface PathElementInterface {
	String getPathValue();
}