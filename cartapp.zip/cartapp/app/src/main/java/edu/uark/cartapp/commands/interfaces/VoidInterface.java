package edu.uark.cartapp.commands.interfaces;

/* ==== APP VoidInterface.java ====*/
public interface VoidInterface {
	void execute();
}