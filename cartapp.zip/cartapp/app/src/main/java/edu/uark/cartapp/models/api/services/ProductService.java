package edu.uark.cartapp.models.api.services;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import edu.uark.cartapp.models.api.Product;
import edu.uark.cartapp.models.api.ProductListing;
import edu.uark.cartapp.models.api.enums.ApiLevel;
import edu.uark.cartapp.models.api.enums.ProductApiMethod;
import edu.uark.cartapp.models.api.enums.ProductApiRequestStatus;
import edu.uark.cartapp.models.api.interfaces.PathElementInterface;

/* ==== APP ProductService.java ====*/
public class ProductService extends BaseRemoteService {
	public Product getProduct(UUID productId) {
		JSONObject rawJsonObject = this.requestSingle((new PathElementInterface[]{ProductApiMethod.PRODUCT, ApiLevel.ONE}), productId);

		if (rawJsonObject != null) {
			return (new Product()).loadFromJson(rawJsonObject);
		} else {
			return new Product().setApiRequestStatus(ProductApiRequestStatus.UNKNOWN_ERROR);
		}
	}

	public Product getProductByLookupCode(String productLookupCode) {
		JSONObject rawJsonObject = this.requestSingle((new PathElementInterface[]{ProductApiMethod.PRODUCT, ApiLevel.ONE, ProductApiMethod.BY_LOOKUP_CODE}), productLookupCode);

		if (rawJsonObject != null) {
			return (new Product()).loadFromJson(rawJsonObject);
		} else {
			return new Product().setApiRequestStatus(ProductApiRequestStatus.UNKNOWN_ERROR);
		}
	}

	public List<Product> getProducts() {
		List<Product> productList;
		JSONObject rawJsonObject = this.requestSingle((new PathElementInterface[]{ProductApiMethod.PRODUCT, ApiLevel.ONE, ProductApiMethod.PRODUCTS}));

		if (rawJsonObject != null) {
			productList = (new ProductListing()).loadFromJson(rawJsonObject).getProductList();
		} else {
			productList = new ArrayList<>(0);
		}
		return productList;
	}

	public Product putProduct(Product product) {
		JSONObject rawJsonObject = this.putSingle((new PathElementInterface[]{ProductApiMethod.PRODUCT, ApiLevel.ONE}), product.convertToJson());

		if (rawJsonObject != null) {
			return (new Product()).loadFromJson(rawJsonObject);
		} else {
			return new Product().setApiRequestStatus(ProductApiRequestStatus.UNKNOWN_ERROR);
		}
	}
}